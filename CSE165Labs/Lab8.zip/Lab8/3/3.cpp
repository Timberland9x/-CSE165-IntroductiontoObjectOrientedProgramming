#include <iostream>
#include "Sortable.h"
#include <vector>

#include <fstream>
#include <string>

using namespace std;

int main(int argc, const char *argv[])
{
    vector<int> v;
    fstream newfile;
    newfile.open("input1.txt", ios::in);
    if (newfile.is_open())
    {

        int num;
        while (newfile >> num)
        {

            Sortable<num>;
        }
    }

    newfile.close();

    return 0;
}