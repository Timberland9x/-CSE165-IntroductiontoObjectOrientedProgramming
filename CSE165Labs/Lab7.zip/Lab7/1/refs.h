#ifndef REFS_H
#define REFS_H

#include <iostream>

void triple(int &num)
{

    // int tri = num;

    num *= 3;
}

// class refs
// {
// public:
//     // int triple(int num)
// };
#endif