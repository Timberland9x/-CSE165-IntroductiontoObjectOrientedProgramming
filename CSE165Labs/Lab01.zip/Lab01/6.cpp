#include <string>
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main()
{
    vector<string> v;
    ifstream in("code.cpp");
    string line;
    string all;
    while (getline(in, line)) // getline returns true if read successfully
        v.push_back(line);    // Add the line to the end of v // Add line numbers:

    // loop through vector
    for (int i = 0; i < v.size(); i++)
    {
        // add each element in vector into string all
        all += v[i];
    }
    // print out string all
    cout << all << endl;
}